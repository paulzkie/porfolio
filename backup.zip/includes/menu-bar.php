<div class="header-nav animate-dropdown">
    <div class="container">
        <div class="yamm navbar navbar-default" role="navigation">
            <div class="navbar-header">
                <button data-target="#mc-horizontal-menu-collapse" data-toggle="collapse" class="navbar-toggle collapsed" type="button">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
            </div>
            <div class="nav-bg-class">
                <div class="navbar-collapse collapse" id="mc-horizontal-menu-collapse">
	<div class="nav-outer">
		<ul class="nav navbar-nav">
			<li class="active dropdown yamm-fw">
				<a href="index.php" data-hover="dropdown" class="dropdown-toggle">Home</a>
			</li>
            <li class=" dropdown yamm-fw">
                <a href="aboutus.php" data-hover="dropdown" class="dropdown-toggle">About Us</a>
            </li>
            <li class=" dropdown yamm-fw">
                <a href="shop.php" data-hover="dropdown" class="dropdown-toggle" >Shop</a>
            </li>
            <li class=" dropdown yamm-fw">
                <a href="faq.php" data-hover="dropdown" class="dropdown-toggle">FAQ's</a>
            </li>
            <li class=" dropdown yamm-fw">
                <a href="tac.php" data-hover="dropdown" class="dropdown-toggle">Terms and Conditions</a>
            </li>
            <li class=" dropdown yamm-fw">
                <a href="contact.php" data-hover="dropdown" class="dropdown-toggle">Contact Us</a>
            </li>

			
		</ul><!-- /.navbar-nav -->
		<div class="clearfix"></div>				
	</div>
</div>


            </div>
        </div>
    </div>
</div>