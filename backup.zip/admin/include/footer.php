	<div class="footer">
		<div class="container">
			 

			<b class="copyright">&copy; 2018 Bulaon Handicrafts </b> All rights reserved.
		</div>
	</div>